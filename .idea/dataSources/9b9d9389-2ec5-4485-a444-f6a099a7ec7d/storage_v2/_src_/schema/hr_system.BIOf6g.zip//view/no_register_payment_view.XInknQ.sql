create view no_register_payment_view as
select '10000000001'                                     AS `salary_payment_id`,
       `hr_system`.`staff_record`.`organization_1_id`    AS `organization_1_id`,
       `hr_system`.`staff_record`.`organization_2_id`    AS `organization_2_id`,
       `hr_system`.`staff_record`.`organization_3_id`    AS `organization_3_id`,
       count(0)                                          AS `number_of_staff`,
       sum(`hr_system`.`salary_standard`.`total_salary`) AS `total_base_salary`,
       2                                                 AS `status`
from (`hr_system`.`staff_record`
         join `hr_system`.`salary_standard`)
where ((`hr_system`.`staff_record`.`status` = 1) and
       (`hr_system`.`staff_record`.`salary_standard_id` = `hr_system`.`salary_standard`.`salary_standard_id`))
group by `hr_system`.`staff_record`.`organization_1_id`, `hr_system`.`staff_record`.`organization_2_id`,
         `hr_system`.`staff_record`.`organization_3_id`;

